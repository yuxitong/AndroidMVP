﻿
本项目是基于okgo网络框架封装的mvp 想使用的话

只需要修改build.gradle中的applicationId和项目包名就可以了

正所谓前人栽树后人乘凉

本项目支持推出activity自动停止当前页面网络请求

LSAlert 各种弹框  utils 里各种工具

已经添加了混淆文件

[https://github.com/jeasonlzy/okhttp-OkGo](https://github.com/jeasonlzy/okhttp-OkGo)

在此特别感谢上述作者，喜欢原作的可以去使用原项目。同时欢迎大家下载体验本项目，如果使用过程中遇到什么问题，欢迎反馈。