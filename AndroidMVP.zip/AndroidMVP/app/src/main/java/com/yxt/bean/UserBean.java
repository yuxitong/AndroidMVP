package com.yxt.bean;

/**
 * Created by 30884 on 2018/5/11.
 */

public class UserBean {
   private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
