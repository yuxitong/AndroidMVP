package com.yxt.network;

/**
 * Created by Administrator on 2017/5/11 0011.
 */
public interface Action1<T> {
    void call(T t);
}
