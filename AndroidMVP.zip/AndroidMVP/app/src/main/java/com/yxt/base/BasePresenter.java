package com.yxt.base;

public interface BasePresenter {
}
